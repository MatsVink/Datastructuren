
/* Example hash function with terrible performance */
unsigned long hash_too_simple(const unsigned char *str);

/* Add the header for your own added hash functions here. You may search online
 * for existing solutions for hashing function, as long as you as you
 * attribute the source, meaning links to the used material.  */
